#include <Wire.h>
#include <SD.h>
#include <Arduino_FreeRTOS.h>

const int chipSelect = 4;

float accX = 0, accY = 0, accZ = 0;

volatile boolean logInitialized = false;
volatile boolean parameterUpdated = false;
volatile boolean dataNormalized = false;

void TaskReadSensor(void *pvParameters);
void TaskInitLog(void *pvParameters);
void TaskUpdateParameter(void *pvParameters);
void TaskNormalizeData(void *pvParameters);
void TaskAddAlert(void *pvParameters);

void setup() {
  Serial.begin(9600);
  delay(2000); 
  
  Serial.println("\nSISTEMA SIGET - GESTOR DE ARCHIVOS");
  
  Wire.begin();
  
  Wire.beginTransmission(0x68);
  Wire.write(0x6B); 
  Wire.write(0);    
  Wire.endTransmission(true);
  
  if (!SD.begin(chipSelect)) {
    Serial.println("ERROR: Fallo al inicializar SD");
    while(1); 
  }
  
  xTaskCreate(TaskReadSensor, "ReadSensor", 200, NULL, 1, NULL);
  vTaskDelay(100 / portTICK_PERIOD_MS);
  
  xTaskCreate(TaskInitLog, "InitLog", 256, NULL, 3, NULL);
  vTaskDelay(100 / portTICK_PERIOD_MS);
  
  xTaskCreate(TaskUpdateParameter, "UpdateParam", 256, NULL, 2, NULL);
  vTaskDelay(100 / portTICK_PERIOD_MS);
  
  xTaskCreate(TaskNormalizeData, "Normalize", 256, NULL, 2, NULL);
  vTaskDelay(100 / portTICK_PERIOD_MS);
  
  xTaskCreate(TaskAddAlert, "AddAlert", 256, NULL, 1, NULL);
}

void loop() {
  vTaskDelay(5000 / portTICK_PERIOD_MS);
}

void TaskReadSensor(void *pvParameters) {
  for (;;) {
    Wire.beginTransmission(0x68);
    Wire.write(0x3B); 
    Wire.endTransmission(false);
    Wire.requestFrom(0x68, 6, true); 
    
    int16_t rawX = Wire.read() << 8 | Wire.read();
    int16_t rawY = Wire.read() << 8 | Wire.read();
    int16_t rawZ = Wire.read() << 8 | Wire.read();
    
    accX = rawX / 16384.0;
    accY = rawY / 16384.0;
    accZ = rawZ / 16384.0;
    
    Serial.print("MPU6050 -> X: ");
    Serial.print(accX, 2);
    Serial.print(" G | Y: ");
    Serial.print(accY, 2);
    Serial.print(" G | Z: ");
    Serial.print(accZ, 2);
    Serial.println(" G");
    
    vTaskDelay(2000 / portTICK_PERIOD_MS); 
  }
}

void TaskInitLog(void *pvParameters) {
  if (SD.exists("log_siget.txt")) {
    SD.remove("log_siget.txt");
  }
  
  File dataFile = SD.open("log_siget.txt", FILE_WRITE);
  
  if (dataFile) {
    dataFile.println("Registro de eventos SIGET - Fecha: 2026-04-06, version: 1.0.0. Este log captura datos cruciales para la optimizacion del trafico");
    dataFile.close();
    logInitialized = true;
  }
  
  vTaskDelete(NULL); 
}

void TaskUpdateParameter(void *pvParameters) {
  while (!logInitialized) {
    vTaskDelay(100 / portTICK_PERIOD_MS);
  }
  
  File dataFile = SD.open("log_siget.txt", FILE_WRITE);
  
  if (dataFile) {
    dataFile.seek(10);
    dataFile.print("ID_SENS_007");
    dataFile.close();
    parameterUpdated = true;
  }
  
  vTaskDelete(NULL);
}

void TaskNormalizeData(void *pvParameters) {
  while (!parameterUpdated) {
    vTaskDelay(100 / portTICK_PERIOD_MS);
  }
  
  File dataFile = SD.open("log_siget.txt");
  if (!dataFile) {
    vTaskDelete(NULL);
    return;
  }
  
  String content = "";
  while (dataFile.available()) {
    content += (char)dataFile.read();
  }
  dataFile.close();
  
  content.replace('3', 'e');
  
  dataFile = SD.open("log_siget.txt", FILE_WRITE);
  if (dataFile) {
    dataFile.seek(0);
    dataFile.print(content);
    dataFile.close();
    dataNormalized = true;
  }
  
  vTaskDelete(NULL);
}

void TaskAddAlert(void *pvParameters) {
  while (!dataNormalized) {
    vTaskDelay(100 / portTICK_PERIOD_MS);
  }
  
  File dataFile = SD.open("log_siget.txt", FILE_WRITE);
  
  if (dataFile) {
    dataFile.seek(dataFile.size());
    
    dataFile.println("");
    dataFile.print("Datos MPU6050: X=");
    dataFile.print(accX, 2);
    dataFile.print(" Y=");
    dataFile.print(accY, 2);
    dataFile.print(" Z=");
    dataFile.println(accZ, 2);
    
    dataFile.println("Alerta: Verifique el estado del servidor de optimizacion de rutas. Contacto: soporte@siget.com");
    dataFile.close();
  }
  
  vTaskDelete(NULL);
}