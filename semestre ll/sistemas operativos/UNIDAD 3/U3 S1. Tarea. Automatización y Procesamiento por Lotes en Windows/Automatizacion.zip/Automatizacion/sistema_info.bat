
@echo off
title Recopilacion de Informacion del Sistema
 
echo Obteniendo hora y fecha...
echo %time% %date% > hora.txt
 
echo Obteniendo sesiones abiertas...
query user > sesiones.txt
 
echo Obteniendo direccion IP...
ipconfig | findstr "IPv4" > dirip.txt
 
echo Obteniendo estadisticas de conexion...
netstat -e > conexion.txt
 
echo Obteniendo espacio en disco...
fsutil volume diskfree C: > dd.txt
copy dd.txt eu.txt
 
echo Obteniendo nombre de la maquina...
echo %computername% > nombre.txt
 
echo Obteniendo directorio actual...
echo %cd% > dir_w.txt
 
echo Obteniendo listado de carpetas de Users...
dir C:\Users /s /b /ad > carpetas.txt
 
echo Obteniendo procesos activos...
tasklist /fo list > procesos.txt
 
echo Obteniendo RAM disponible...
typeperf "\Memory\Available MBytes" -sc 1 > mem.txt
 
echo Obteniendo inventario del sistema...
echo Nombre: %computername% > inv.txt
echo Usuario: %username% >> inv.txt
echo Sistema: %os% >> inv.txt
echo Fecha: %date% >> inv.txt
echo Hora: %time% >> inv.txt
ipconfig /all >> inv.txt
 
echo Organizando archivos en carpetas...
mkdir ResultadosSistema
cd ResultadosSistema
mkdir Red_y_Conexiones
mkdir Sistema_y_Hardware
mkdir Almacenamiento_y_Rutas
 
echo Moviendo archivos...
move ..\dirip.txt Red_y_Conexiones\
move ..\conexion.txt Red_y_Conexiones\
move ..\sesiones.txt Red_y_Conexiones\
 
move ..\hora.txt Sistema_y_Hardware\
move ..\mem.txt Sistema_y_Hardware\
move ..\nombre.txt Sistema_y_Hardware\
move ..\inv.txt Sistema_y_Hardware\
move ..\procesos.txt Sistema_y_Hardware\
 
move ..\dd.txt Almacenamiento_y_Rutas\
move ..\eu.txt Almacenamiento_y_Rutas\
move ..\dir_w.txt Almacenamiento_y_Rutas\
move ..\carpetas.txt Almacenamiento_y_Rutas\
 
echo.
echo Proceso finalizado con exito!
echo Los archivos estan en la carpeta ResultadosSistema
pause