@echo off
title Sistema Inteligente de Gestion de Trafico - SIGET
echo     SIGET - Automatizacion de Monitoreo
echo.
 
:: PARTE 1: RECOLECCION DE INFORMACION
 
echo [1/11] Registrando hora y fecha de monitoreo...
echo %date% %time% > SIGET_monitoreo_hora.txt
 
echo [2/11] Registrando sesiones de operadores...
query user > SIGET_sesiones_operadores.txt
 
echo [3/11] Capturando direccion IP de modulos...
ipconfig | findstr "IPv4" > SIGET_red_ip.txt
 
echo [4/11] Obteniendo estadisticas de red...
netstat -e > SIGET_red_estadisticas.txt
 
echo [5/11] Midiendo consumo de RAM...
typeperf "\Memory\Available MBytes" -sc 1 > SIGET_recursos_ram.txt
 
echo [6/11] Verificando almacenamiento en disco...
fsutil volume diskfree C: > SIGET_almacenamiento_disco.txt
copy SIGET_almacenamiento_disco.txt SIGET_almacenamiento_usado.txt > nul
 
echo [7/11] Identificando servidor de procesamiento...
echo %computername% > SIGET_servidor_nombre.txt
 
echo [8/11] Registrando ruta de ejecucion...
echo %cd% > SIGET_ruta_ejecucion.txt
 
echo [9/11] Generando inventario de carpetas de Users...
dir C:\Users /s /b /ad > SIGET_inventario_carpetas.txt
 
echo [10/11] Generando inventario general del sistema...
echo === INVENTARIO GENERAL SIGET === > SIGET_inventario_general.txt
echo Nombre maquina: %computername% >> SIGET_inventario_general.txt
echo Usuario: %username% >> SIGET_inventario_general.txt
echo Sistema operativo: %os% >> SIGET_inventario_general.txt
echo Fecha: %date% >> SIGET_inventario_general.txt
echo Hora: %time% >> SIGET_inventario_general.txt
echo. >> SIGET_inventario_general.txt
ipconfig /all >> SIGET_inventario_general.txt
 
echo [11/11] Registrando procesos activos...
tasklist /fo list > SIGET_procesos_activos.txt
 
echo.
echo [OK] Recoleccion de datos completada.
echo.

:: PARTE 2: CREACION DE ESTRUCTURA DE CARPETAS
 
echo Creando estructura de modulos SIGET en C:\...
 
if not exist C:\SIGET_CORE\ (
    mkdir C:\SIGET_CORE
    echo [OK] Carpeta C:\SIGET_CORE creada.
) else (
    echo [INFO] C:\SIGET_CORE ya existe, continuando...
)
 
if not exist C:\SIGET_CORE\MODULO_SENSORES\ (
    mkdir C:\SIGET_CORE\MODULO_SENSORES
    echo [OK] MODULO_SENSORES creado.
) else (
    echo [INFO] MODULO_SENSORES ya existe.
)
 
if not exist C:\SIGET_CORE\MODULO_ANALISIS\ (
    mkdir C:\SIGET_CORE\MODULO_ANALISIS
    echo [OK] MODULO_ANALISIS creado.
) else (
    echo [INFO] MODULO_ANALISIS ya existe.
)
 
if not exist C:\SIGET_CORE\LOGS_AUDITORIA\ (
    mkdir C:\SIGET_CORE\LOGS_AUDITORIA
    echo [OK] LOGS_AUDITORIA creado.
) else (
    echo [INFO] LOGS_AUDITORIA ya existe.
)
 
if not exist C:\SIGET_CORE\MODULO_WEB\ (
    mkdir C:\SIGET_CORE\MODULO_WEB
    echo [OK] MODULO_WEB creado.
) else (
    echo [INFO] MODULO_WEB ya existe.
)
 
echo.
echo [OK] Estructura de carpetas lista.
echo.
 
:: PARTE 3: DISTRIBUCION DE ARCHIVOS
 
echo Distribuyendo archivos de monitoreo...
 
echo Copiando a MODULO_WEB...
copy SIGET_monitoreo_hora.txt C:\SIGET_CORE\MODULO_WEB\ > nul
copy SIGET_inventario_general.txt C:\SIGET_CORE\MODULO_WEB\ > nul
copy SIGET_servidor_nombre.txt C:\SIGET_CORE\MODULO_WEB\ > nul
 
echo Copiando a MODULO_SENSORES...
copy SIGET_sesiones_operadores.txt C:\SIGET_CORE\MODULO_SENSORES\ > nul
copy SIGET_ruta_ejecucion.txt C:\SIGET_CORE\MODULO_SENSORES\ > nul
copy SIGET_inventario_carpetas.txt C:\SIGET_CORE\MODULO_SENSORES\ > nul
 
echo Copiando a MODULO_ANALISIS...
copy SIGET_red_ip.txt C:\SIGET_CORE\MODULO_ANALISIS\ > nul
copy SIGET_red_estadisticas.txt C:\SIGET_CORE\MODULO_ANALISIS\ > nul
 
echo Copiando a LOGS_AUDITORIA...
copy SIGET_recursos_ram.txt C:\SIGET_CORE\LOGS_AUDITORIA\ > nul
copy SIGET_almacenamiento_disco.txt C:\SIGET_CORE\LOGS_AUDITORIA\ > nul
copy SIGET_almacenamiento_usado.txt C:\SIGET_CORE\LOGS_AUDITORIA\ > nul
 
echo Moviendo SIGET_procesos_activos.txt a LOGS_AUDITORIA...
move SIGET_procesos_activos.txt C:\SIGET_CORE\LOGS_AUDITORIA\ > nul
 
echo.
echo [OK] Distribucion de archivos completada.
echo.
 
:: PARTE 4: SIMULACRO DE ACTUALIZACION
 
echo Copiando archivos .exe de C:\Windows\ a MODULO_SENSORES...
for %%f in (C:\Windows\*.exe) do (
    echo Copiando %%~nxf ...
    copy "%%f" C:\SIGET_CORE\MODULO_SENSORES\ > nul
)
 
echo.
echo Copiando archivos .dll de C:\Windows\System32\ a MODULO_ANALISIS...
for %%f in (C:\Windows\System32\*.dll) do (
    echo Copiando %%~nxf ...
    copy "%%f" C:\SIGET_CORE\MODULO_ANALISIS\ > nul
)
 
echo.
echo [OK] Simulacro de actualizacion completado.
echo.
 
:: PARTE 5: VERSIONADO - RENOMBRAR .exe a .OLD
 
echo Renombrando archivos .exe a .OLD en MODULO_SENSORES...
for %%f in (C:\SIGET_CORE\MODULO_SENSORES\*.exe) do (
    echo Renombrando %%~nxf a %%~nf.OLD ...
    ren "%%f" "%%~nf.OLD"
)
 
echo.
echo [OK] Versionado completado.
echo.
 
:: PARTE 6: LIMPIEZA DE LOGS QUE EMPIEZAN CON S
 
echo Eliminando logs obsoletos que empiezan con S en LOGS_AUDITORIA...
for %%f in (C:\SIGET_CORE\LOGS_AUDITORIA\S*.*) do (
    echo Eliminando %%~nxf ...
    del "%%f"
)
 
echo.
echo [OK] Limpieza de logs completada.
echo.
 
:: FIN DEL SCRIPT
 
echo   SIGET - Proceso finalizado con exito!
echo.
echo Estructura creada en C:\SIGET_CORE\
echo.
pause